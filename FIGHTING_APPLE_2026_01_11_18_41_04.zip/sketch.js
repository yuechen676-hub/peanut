// FIGHTING APPLE — 3 Levels + Full-Screen Rising Bubbles (Top Layer)
// p5.js + p5.sound only. Responsive. No external libs.
// Volume drives movement. Steady voice spawns affirmation bubbles rising bottom->top.
// Bubbles always draw on top of EVERYTHING.

let mic, amp;

let state = "intro"; // intro -> calibrate -> play -> levelClear -> win
let calibrationStart = 0;

let noiseFloor = 0.02;
let baseThreshold = 0.12;      // after calibration
let dynamicThreshold = 0.12;   // modified by blessing
let sensitivity = 1.0;

let vol = 0;        // smoothed
let prevVol = 0;

let runner;
let bonds = [];
let bubbles = [];

// manifestation / nurture
let nurtureMeter = 0; // 0..1
let blessing = 0;     // 0..1
let affirmCount = 0;  // total bubbles ever spawned (world "remembers")

let stableFrames = 0;
let bubbleCooldown = 0;

// screen shake
let screenShake = 0;

// pixel scale
let PX = 6;

// slider
let slider = {
  x: 0, y: 0, w: 260, h: 18,
  min: 0.6, max: 1.8,
  dragging: false
};

let startBtn = { x: 0, y: 0, w: 0, h: 0 };

// --- levels ---
let level = 1;
const maxLevel = 3;
let levelClearAt = 0;

const AFFIRM = [
  "I can do this.",
  "One step.",
  "Fighting!",
  "I am enough.",
  "I’m learning.",
  "Keep going.",
  "I trust myself.",
  "I’m proud of me.",
  "Slow is okay.",
  "I choose kindness.",
  "I’m getting stronger."
];

// --- Palette (pink UI + apple colors closer to ref) ---
const PAL = {
  bg1: [255, 244, 249],
  bg2: [255, 229, 241],

  panel:  [255, 236, 246],
  panel2: [255, 250, 253],

  border: [214, 160, 186],

  text:   [55, 40, 55],
  mute:   [130, 95, 120],

  gold:   [255, 200, 120],

  // apple palette
  appleRed:    [232, 56, 74],
  appleDark:   [176, 34, 55],
  appleDarker: [120, 20, 38],
  appleHi:     [255, 120, 140],
  appleYellow: [255, 212, 80],
  leaf:        [70, 170, 90],
  leafDark:    [40, 120, 70],
  stem:        [135, 85, 55],

  limb:        [40, 55, 85],
  limbDark:    [25, 35, 60],

  chainLight: [210, 220, 235],
  chainDark:  [150, 160, 180]
};

// --- Apple sprite ---
const APPLE_REF = [
  "       ggGG       ",
  "      gGGGGG      ",
  "        BB        ",
  "      OOBBOO      ",
  "    ODDRRRRDDO    ",
  "   ODRRRRRRRRDO   ",
  "  ODRRRRRRRRRRDO  ",
  "  ODRRRRRRRRRRDO  ",
  " ODRRRRRRYYRRRRDO ",
  " ODRRRRRRYYRRRRDO ",
  " ODRRRRRRRRRRRRDO ",
  "  ODRRRRRRRRRRDO  ",
  "   ODDRRRRRRDDO   ",
  "     OOOOOOOO     ",
  "    lL     Ll     ",
  "    lL     Ll     "
];

// --- Tiny 5x7 bitmap font (uppercase + space + ! + .) ---
const FONT_5x7 = {
  "A":["01110","10001","10001","11111","10001","10001","10001"],
  "B":["11110","10001","10001","11110","10001","10001","11110"],
  "C":["01110","10001","10000","10000","10000","10001","01110"],
  "D":["11110","10001","10001","10001","10001","10001","11110"],
  "E":["11111","10000","10000","11110","10000","10000","11111"],
  "F":["11111","10000","10000","11110","10000","10000","10000"],
  "G":["01110","10001","10000","10111","10001","10001","01110"],
  "H":["10001","10001","10001","11111","10001","10001","10001"],
  "I":["01110","00100","00100","00100","00100","00100","01110"],
  "J":["00111","00010","00010","00010","00010","10010","01100"],
  "K":["10001","10010","10100","11000","10100","10010","10001"],
  "L":["10000","10000","10000","10000","10000","10000","11111"],
  "M":["10001","11011","10101","10101","10001","10001","10001"],
  "N":["10001","11001","10101","10011","10001","10001","10001"],
  "O":["01110","10001","10001","10001","10001","10001","01110"],
  "P":["11110","10001","10001","11110","10000","10000","10000"],
  "Q":["01110","10001","10001","10001","10101","10010","01101"],
  "R":["11110","10001","10001","11110","10100","10010","10001"],
  "S":["01111","10000","10000","01110","00001","00001","11110"],
  "T":["11111","00100","00100","00100","00100","00100","00100"],
  "U":["10001","10001","10001","10001","10001","10001","01110"],
  "V":["10001","10001","10001","10001","10001","01010","00100"],
  "W":["10001","10001","10001","10101","10101","11011","10001"],
  "X":["10001","01010","00100","00100","00100","01010","10001"],
  "Y":["10001","01010","00100","00100","00100","00100","00100"],
  "Z":["11111","00001","00010","00100","01000","10000","11111"],
  " ":["00000","00000","00000","00000","00000","00000","00000"],
  "!":["00100","00100","00100","00100","00100","00000","00100"],
  ".":["00000","00000","00000","00000","00000","00110","00110"]
};

function setup() {
  createCanvas(windowWidth, windowHeight);
  textFont("monospace");
  noSmooth();

  mic = new p5.AudioIn();
  amp = new p5.Amplitude();
  amp.smooth(0.85);

  runner = new Runner();
  resetGame();
}

function resetGame() {
  state = "intro";

  vol = 0;
  prevVol = 0;

  nurtureMeter = 0;
  blessing = 0;
  affirmCount = 0;

  stableFrames = 0;
  bubbleCooldown = 0;

  bubbles = [];
  bonds = [];

  baseThreshold = 0.12;
  dynamicThreshold = baseThreshold;
  noiseFloor = 0.02;

  screenShake = 0;

  level = 1;
  buildLevel(level);
}

function buildLevel(lvl) {
  runner.resetProgress();

  // base strength grows slightly per level (still easy)
  runner.baseChainStrength = 1.35 + (lvl - 1) * 0.12;
  runner.chainStrengthNow = runner.baseChainStrength;

  // more chains each level
  const count = 7 + (lvl - 1) * 2; // 7, 9, 11
  bonds = [];
  for (let i = 0; i < count; i++) {
    let t = (i + 1) / (count + 1);
    let x = lerp(runner.startX, runner.goalX, t);
    bonds.push(new Bond(x));
  }

  // level starts with small reset of per-level nurture
  nurtureMeter = 0;
  stableFrames = 0;
  bubbleCooldown = 0;
}

function draw() {
  updatePX();
  layoutUI();
  drawPixelBackground();

  if (state === "calibrate" || state === "play") updateAudio();
  if (state === "calibrate") updateCalibration();

  if (state === "play") {
    updateWorldRules();
    updatePlay();
  }

  // screen shake camera
  let shakeX = 0, shakeY = 0;
  if (screenShake > 0) {
    screenShake *= 0.85;
    shakeX = round(random(-screenShake, screenShake));
    shakeY = round(random(-screenShake, screenShake));
  }

  // world layer
  push();
  translate(shakeX, shakeY);
  runner.drawTrack();
  for (let b of bonds) b.draw();
  runner.draw();
  pop();

  // HUD + overlays
  drawHUD();
  if (state === "intro") drawIntroOverlay();
  if (state === "calibrate") drawCalibrateOverlay();
  if (state === "levelClear") drawLevelClearOverlay();
  if (state === "win") drawWinOverlay();

  //  BUBBLES ALWAYS TOP LAYER: draw after HUD/overlays
  for (let i = bubbles.length - 1; i >= 0; i--) {
    bubbles[i].update();
    bubbles[i].draw();
    if (bubbles[i].dead) bubbles.splice(i, 1);
  }
}

function updatePX() {
  PX = constrain(round(min(width, height) / 120), 4, 10);
}

function layoutUI() {
  slider.x = width * 0.08;
  slider.y = height * 0.88;
}

function updateAudio() {
  let raw = amp.getLevel();
  let scaled = raw * sensitivity;
  vol = lerp(vol, scaled, 0.22);
}

function updateCalibration() {
  let v = amp.getLevel();
  noiseFloor = lerp(noiseFloor, v, 0.08);

  if (millis() - calibrationStart > 2000) {
    baseThreshold = constrain(noiseFloor * 3.2, 0.06, 0.22);
    dynamicThreshold = baseThreshold;
    state = "play";
  }
}

function updateWorldRules() {
  // “world remembers”: more bubbles => easier
  blessing = constrain(affirmCount / 20, 0, 1);

  dynamicThreshold = baseThreshold * (1 - 0.30 * blessing);
  dynamicThreshold = constrain(dynamicThreshold, 0.05, 0.25);

  runner.chainStrengthNow = runner.baseChainStrength * (1 - 0.38 * blessing);
}

function updatePlay() {
  let dv = vol - prevVol;
  prevVol = vol;

  let drive = max(0, vol - dynamicThreshold);
  let driveNorm = constrain(drive / (0.5 - dynamicThreshold), 0, 1);

  runner.energy = lerp(runner.energy, driveNorm * 3.2, 0.15);

  let speed = (PX * 0.55 + PX * 1.35 * driveNorm) * (1 + 0.55 * blessing);
  runner.x += speed;
  runner.x = constrain(runner.x, runner.startX, runner.goalX);

  // steady voice detection => bubbles
  let stable = abs(dv) < dynamicThreshold * 0.30;
  let above = vol > dynamicThreshold * 0.95;

  if (above && stable) {
    stableFrames++;
    nurtureMeter = constrain(nurtureMeter + 0.02, 0, 1);
  } else {
    stableFrames = max(0, stableFrames - 2);
    nurtureMeter *= 0.992;
  }

  if (bubbleCooldown > 0) bubbleCooldown--;
  if (stableFrames > 10 && bubbleCooldown === 0) {
    spawnAffirmationFromBottom();
    bubbleCooldown = 22;
  }

  // chain collision
  let nextBond = getNextBond();
  if (nextBond && !nextBond.broken) {
    if (runner.x + runner.headRadius >= nextBond.x) {
      let ok = nextBond.tryBreak(runner.energy, runner.chainStrengthNow);

      if (ok) {
        runner.bumpForward(PX * 4);
        screenShake = max(screenShake, 8);
      } else {
        runner.bumpBack(PX * 2);
        screenShake = max(screenShake, 4);
      }
    }
  }

  // level finish
  if (runner.x >= runner.goalX) {
    state = (level < maxLevel) ? "levelClear" : "win";
    levelClearAt = millis();
  }
}

function getNextBond() {
  for (let b of bonds) if (!b.broken) return b;
  return null;
}

//  New bubble behavior: spawn at bottom, float to top, always on top layer
function spawnAffirmationFromBottom() {
  let text = random(AFFIRM);

  let bx = random(width * 0.12, width * 0.88);
  let by = height + PX * random(8, 18); // start off-screen bottom

  bubbles.push(new Bubble(text, bx, by));
  affirmCount++;
}

// ---------- Drawing ----------

function drawPixelBackground() {
  background(...PAL.bg1);

  let tile = PX * 6;
  noStroke();
  for (let y = 0; y < height; y += tile) {
    for (let x = 0; x < width; x += tile) {
      let v = ((x / tile + y / tile) % 2 === 0) ? PAL.bg2 : PAL.bg1;
      fill(v[0], v[1], v[2]);
      rect(x, y, tile, tile);
    }
  }

  let glow = blessing * 120;
  noFill();
  stroke(255, 180, 210, glow);
  strokeWeight(PX);
  ellipse(snap(width * 0.5), snap(height * 0.62), snap(PX * 34 + blessing * PX * 18));
  noStroke();
}

function drawHUD() {
  drawPixelPanel(width * 0.06, height * 0.04, width * 0.88, height * 0.12);

  // Pixel title in apple color
  drawPixelText("FIGHTING APPLE", width * 0.08 + PX, height * 0.056 + PX, PX * 1.15, PAL.appleDark);
  drawPixelText("FIGHTING APPLE", width * 0.08,       height * 0.056,      PX * 1.15, PAL.appleRed);

  fill(...PAL.mute);
  textSize(PX * 1.3);
  textAlign(LEFT, TOP);
  text("LOUDER = MOVE • STEADY = WORDS • WORDS = EASIER WORLD", width * 0.08, height * 0.118);

  drawPixelPanel(width * 0.06, height * 0.17, width * 0.52, height * 0.26);
  drawPixelBar(width * 0.08, height * 0.20, width * 0.48, PX * 3, vol / 0.5, "VOL", dynamicThreshold / 0.5);
  drawPixelBar(width * 0.08, height * 0.25, width * 0.48, PX * 3, runner.energy / 3.2, "ENG");
  drawPixelBar(width * 0.08, height * 0.30, width * 0.48, PX * 3, nurtureMeter, "NUR");

  fill(...PAL.text);
  textSize(PX * 1.8);
  textAlign(LEFT, TOP);
  text(`LEVEL ${level}/${maxLevel}`, width * 0.08, height * 0.35);

  fill(...PAL.mute);
  textSize(PX * 1.5);
  text(`BLESSING ${(blessing * 100) | 0}%  (WORDS: ${affirmCount})`, width * 0.22, height * 0.35);

  fill(...PAL.mute);
  textSize(PX * 1.4);
  text(`Threshold ${dynamicThreshold.toFixed(3)} • Chain ${runner.chainStrengthNow.toFixed(2)}`, width * 0.08, height * 0.38);

  drawPixelPanel(width * 0.60, height * 0.17, width * 0.34, height * 0.26);
  fill(...PAL.text);
  textAlign(LEFT, TOP);
  textSize(PX * 2);
  text("TIPS", width * 0.62, height * 0.20);

  fill(...PAL.mute);
  textSize(PX * 1.5);
  text(
    "• Louder => move faster\n" +
    "• Steady voice => bubbles\n" +
    "• Bubbles rise bottom->top\n" +
    "• More words => easier\n" +
    "• Break chains to clear level!",
    width * 0.62, height * 0.24
  );

  drawPixelPanel(width * 0.06, height * 0.84, width * 0.88, height * 0.12);
  drawSensitivitySliderPixel();
}

function drawIntroOverlay() {
  drawOverlayBox(() => {
    drawPixelTextBox("WELCOME", width * 0.18, height * 0.22, width * 0.64, height * 0.10);

    fill(...PAL.text);
    textAlign(LEFT, TOP);
    textSize(PX * 1.7);
    text(
      "1) CLICK START + ALLOW MIC\n" +
      "2) STAY QUIET 2s (CALIBRATION)\n" +
      "3) LOUDER = MOVE FORWARD\n" +
      "4) STEADY voice = bubbles\n" +
      "   => world becomes easier\n\n" +
      "Clear 3 levels. SPACE = next level.",
      width * 0.20, height * 0.34
    );

    let bx = width * 0.20;
    let by = height * 0.72;
    let bw = min(340, width * 0.48);
    let bh = PX * 10;
    startBtn = { x: bx, y: by, w: bw, h: bh };
    drawPixelButton(bx, by, bw, bh, "START");
  });
}

function drawCalibrateOverlay() {
  drawOverlayBox(() => {
    drawPixelTextBox("CALIBRATING…", width * 0.18, height * 0.30, width * 0.64, height * 0.10);

    fill(...PAL.text);
    textAlign(LEFT, TOP);
    textSize(PX * 1.7);

    let t = (millis() - calibrationStart) / 2000;
    t = constrain(t, 0, 1);

    text("Stay quiet for 2 seconds.\nWe find a fair threshold.", width * 0.20, height * 0.44);
    drawPixelBar(width * 0.20, height * 0.58, width * 0.60, PX * 4, t, "QUIET");
  });
}

function drawLevelClearOverlay() {
  drawOverlayBox(() => {
    drawPixelTextBox("LEVEL CLEAR!", width * 0.18, height * 0.28, width * 0.64, height * 0.10);

    fill(...PAL.text);
    textAlign(LEFT, TOP);
    textSize(PX * 1.7);

    text(
      `You cleared Level ${level}.\n\n` +
      "Press SPACE to continue.",
      width * 0.20, height * 0.44
    );
  });
}

function drawWinOverlay() {
  drawOverlayBox(() => {
    drawPixelTextBox("YOU DID IT!", width * 0.18, height * 0.28, width * 0.64, height * 0.10);

    fill(...PAL.text);
    textAlign(LEFT, TOP);
    textSize(PX * 1.7);

    text(
      "You cleared all 3 levels.\n\n" +
      `Words written into the world: ${affirmCount}\n` +
      `Blessing: ${(blessing * 100) | 0}%\n\n` +
      "Press R to restart.",
      width * 0.20, height * 0.44
    );
  });
}

function drawOverlayBox(drawContentFn) {
  noStroke();
  fill(0, 120);
  rect(0, 0, width, height);

  let x = width * 0.14;
  let y = height * 0.16;
  let w = width * 0.72;
  let h = height * 0.70;

  drawPixelPanel(x, y, w, h);
  drawContentFn();
}

// ---------- UI primitives ----------

function drawPixelPanel(x, y, w, h) {
  x = snap(x); y = snap(y); w = snap(w); h = snap(h);

  noStroke();
  fill(...PAL.panel);
  rect(x, y, w, h);

  fill(...PAL.panel2);
  rect(x + PX, y + PX, w - PX * 2, h - PX * 2);

  noFill();
  stroke(...PAL.border);
  strokeWeight(PX);
  rect(x, y, w, h);
  noStroke();
}

function drawPixelTextBox(label, x, y, w, h) {
  drawPixelPanel(x, y, w, h);
  fill(...PAL.gold);
  textAlign(LEFT, TOP);
  textSize(PX * 2.2);
  text(label, x + PX * 2, y + PX * 1.5);
}

function drawPixelButton(x, y, w, h, label) {
  x = snap(x); y = snap(y); w = snap(w); h = snap(h);
  let hover = mouseX > x && mouseX < x + w && mouseY > y && mouseY < y + h;

  noStroke();
  fill(...(hover ? PAL.gold : PAL.panel2));
  rect(x, y, w, h);

  noFill();
  stroke(...PAL.border);
  strokeWeight(PX);
  rect(x, y, w, h);
  noStroke();

  fill(hover ? 40 : PAL.text[0], hover ? 30 : PAL.text[1], hover ? 40 : PAL.text[2]);
  textAlign(CENTER, CENTER);
  textSize(PX * 2.2);
  text(label, x + w / 2, y + h / 2);
}

function drawPixelBar(x, y, w, h, t, label, markerT = null) {
  x = snap(x); y = snap(y); w = snap(w); h = snap(h);

  noStroke();
  fill(255, 250, 253);
  rect(x, y, w, h);

  let blocks = floor(w / (PX * 2));
  let filled = floor(constrain(t, 0, 1) * blocks);

  for (let i = 0; i < blocks; i++) {
    let bx = x + i * PX * 2;
    fill(i < filled ? 120 : 220, i < filled ? 220 : 200, i < filled ? 255 : 210);
    rect(bx, y, PX * 2 - PX / 2, h);
  }

  if (markerT !== null) {
    let mx = snap(x + constrain(markerT, 0, 1) * w);
    fill(255, 120, 150);
    rect(mx, y - PX, PX, h + PX * 2);
  }

  fill(...PAL.mute);
  textAlign(LEFT, BOTTOM);
  textSize(PX * 1.4);
  text(label, x, y - PX);
}

function drawSensitivitySliderPixel() {
  let x = width * 0.08;
  let y = height * 0.875;
  let w = width * 0.78;
  let h = PX * 3;

  x = snap(x); y = snap(y); w = snap(w); h = snap(h);

  fill(...PAL.mute);
  textAlign(LEFT, BOTTOM);
  textSize(PX * 1.5);
  text(`SENS ${sensitivity.toFixed(2)} (DRAG)`, x, y - PX);

  fill(255, 250, 253);
  rect(x, y, w, h);

  let t = map(sensitivity, slider.min, slider.max, 0, 1, true);
  let kx = snap(x + t * w);

  fill(...PAL.gold);
  rect(kx - PX * 2, y - PX, PX * 4, h + PX * 2);

  slider.x = x;
  slider.y = y;
  slider.w = w;
  slider.h = h;
}

function snap(v) { return round(v / PX) * PX; }

// ---------- Pixel Font drawing ----------

function drawPixelText(str, x, y, s, colRGB) {
  str = (str || "").toUpperCase();
  let cursorX = x;
  let cursorY = y;

  noStroke();
  fill(colRGB[0], colRGB[1], colRGB[2]);

  let charW = 5;
  let charH = 7;
  let gap = s * 2;
  let dot = s;

  for (let i = 0; i < str.length; i++) {
    let ch = str[i];
    let glyph = FONT_5x7[ch] || FONT_5x7[" "];

    for (let r = 0; r < charH; r++) {
      for (let c = 0; c < charW; c++) {
        if (glyph[r][c] === "1") {
          rect(snap(cursorX + c * dot), snap(cursorY + r * dot), dot, dot);
        }
      }
    }
    cursorX += charW * dot + gap;
  }
}

// ---------- Input ----------

function mousePressed() {
  if (state === "intro") {
    if (mouseX > startBtn.x && mouseX < startBtn.x + startBtn.w &&
        mouseY > startBtn.y && mouseY < startBtn.y + startBtn.h) {
      userStartAudio();
      mic.start(() => {
        amp.setInput(mic);
        state = "calibrate";
        calibrationStart = millis();
        noiseFloor = 0.02;
      });
    }
    return;
  }

  if (mouseX > slider.x && mouseX < slider.x + slider.w &&
      mouseY > slider.y - PX * 2 && mouseY < slider.y + slider.h + PX * 2) {
    slider.dragging = true;
    updateSliderValue();
  }
}

function mouseDragged() {
  if (slider.dragging) updateSliderValue();
}

function mouseReleased() {
  slider.dragging = false;
}

function updateSliderValue() {
  let t = constrain((mouseX - slider.x) / slider.w, 0, 1);
  sensitivity = lerp(slider.min, slider.max, t);
}

function keyPressed() {
  if (key === 'r' || key === 'R') resetGame();

  if (state === "levelClear" && keyCode === 32) { // SPACE
    level++;
    if (level <= maxLevel) {
      buildLevel(level);
      state = "play";
    } else {
      state = "win";
    }
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  noSmooth();
  // rebuild current level layout responsively
  buildLevel(level);
}

// ---------- Classes ----------

class Runner {
  constructor() {
    this.headRadius = 16;
    this.baseChainStrength = 1.35;
    this.chainStrengthNow = this.baseChainStrength;
    this.resetProgress();
  }

  resetProgress() {
    this.startX = width * 0.12;
    this.goalX = width * 0.88;
    this.y = height * 0.62;
    this.x = this.startX;
    this.energy = 0;
  }

  bumpForward(px) { this.x += px; }
  bumpBack(px) { this.x -= px; }

  drawTrack() {
    let y = snap(this.y);
    let sx = snap(this.startX);
    let gx = snap(this.goalX);

    fill(255, 250, 253);
    rect(sx, y - PX * 2, gx - sx, PX * 4);

    fill(230, 210, 220);
    for (let i = 0; i < 11; i++) {
      let x = snap(lerp(sx, gx, i / 10));
      rect(x, y - PX * 3, PX, PX * 6);
    }

    let doorW = PX * 6;
    let doorH = PX * 12;
    fill(...PAL.gold);
    rect(gx - doorW / 2, y - doorH / 2, doorW, doorH);
    fill(40, 30, 40, 90);
    rect(gx - doorW / 2 + PX, y - doorH / 2 + PX, doorW - PX * 2, doorH - PX * 2);
  }

  draw() {
    let x = snap(this.x);
    let y = snap(this.y);

    if (this.energy > 0.2) {
      noFill();
      stroke(255, 120, 170, 40 + blessing * 70);
      strokeWeight(PX);
      ellipse(x, y, PX * (10 + this.energy * 8 + blessing * 6));
      noStroke();
    }

    drawSprite(APPLE_REF, x, y - PX * 2, PX);
    drawAppleFace(x, y - PX * 2, PX);
  }
}

class Bond {
  constructor(x) {
    this.x = x;
    this.broken = false;
  }

  tryBreak(energy, strengthNow) {
    if (this.broken) return false;
    if (energy > strengthNow) {
      this.broken = true;
      return true;
    }
    return false;
  }

  draw() {
    if (this.broken) return;

    let y = snap(runner.y);
    let x = snap(this.x);
    let h = snap(height * 0.22);

    drawChainColumn(x, y, h);

    fill(...PAL.mute);
    textAlign(CENTER, TOP);
    textSize(PX * 1.4);
    text("chain", x, y + h + PX);
  }
}

class Bubble {
  constructor(text, x, y) {
    this.text = text;
    this.x = x;
    this.y = y;

    this.w = min(width * 0.30, 420);
    this.h = PX * 6;

    this.vx = random(-0.12, 0.12) * PX;
    this.vy = -random(0.8, 1.35) * PX;

    this.alpha = 255;
    this.dead = false;
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;

    // gentle drift
    this.vx = lerp(this.vx, random(-0.10, 0.10) * PX, 0.02);

    // fade as it rises (later)
    if (this.y < height * 0.35) this.alpha *= 0.987;

    if (this.y + this.h < -PX * 10 || this.alpha < 8) this.dead = true;
  }

  draw() {
    let x = snap(this.x);
    let y = snap(this.y);
    let w = snap(this.w);
    let h = snap(this.h);

    noStroke();
    fill(PAL.panel2[0], PAL.panel2[1], PAL.panel2[2], this.alpha);
    rect(x, y, w, h);

    stroke(PAL.border[0], PAL.border[1], PAL.border[2], this.alpha);
    strokeWeight(PX);
    noFill();
    rect(x, y, w, h);
    noStroke();

    fill(PAL.text[0], PAL.text[1], PAL.text[2], this.alpha);
    textAlign(LEFT, CENTER);
    textSize(PX * 1.6);

    let s = this.text;
    if (s.length > 24) s = s.slice(0, 23) + "…";
    text(s, x + PX * 2, y + h / 2);
  }
}

// ---------- Chain + Sprite helpers ----------

function drawChainColumn(x, yCenter, h) {
  for (let yy = yCenter - h; yy <= yCenter + h; yy += PX * 3) {
    fill(...PAL.chainDark, 230);
    rect(x - PX * 3, yy - PX, PX * 6, PX * 2);
    rect(x - PX, yy - PX * 2, PX * 2, PX * 4);

    fill(...PAL.chainLight, 220);
    rect(x - PX * 2, yy - PX / 2, PX * 4, PX);
    rect(x - PX / 2, yy - PX * 1.5, PX, PX * 3);
  }
}

function drawSprite(sprite, cx, cy, scale) {
  let rows = sprite.length;
  let cols = sprite[0].length;
  let x0 = cx - floor(cols / 2) * scale;
  let y0 = cy - floor(rows / 2) * scale;

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      let ch = sprite[r][c];
      if (ch === " ") continue;

      let col = null;
      if (ch === "R") col = PAL.appleRed;
      if (ch === "D") col = PAL.appleDark;
      if (ch === "O") col = PAL.appleDarker;
      if (ch === "H") col = PAL.appleHi;
      if (ch === "Y") col = PAL.appleYellow;
      if (ch === "G") col = PAL.leaf;
      if (ch === "g") col = PAL.leafDark;
      if (ch === "B") col = PAL.stem;
      if (ch === "L") col = PAL.limb;
      if (ch === "l") col = PAL.limbDark;

      if (!col) continue;

      fill(col[0], col[1], col[2]);
      rect(snap(x0 + c * scale), snap(y0 + r * scale), scale, scale);
    }
  }
}

function drawAppleFace(cx, cy, s) {
  fill(PAL.limbDark[0], PAL.limbDark[1], PAL.limbDark[2]);
  noStroke();

  // left eye (2 pixels tall, match right)
  rect(snap(cx - s * 3), snap(cy + s * 1), s, s);
  rect(snap(cx - s * 3), snap(cy + s * 2), s, s);

  // right blue edge near yellow highlight
  rect(snap(cx + s * 1), snap(cy + s * 1), s, s);
  rect(snap(cx + s * 1), snap(cy + s * 2), s, s);

  // mouth (flat)
  rect(snap(cx - s * 1), snap(cy + s * 5), s * 2, s);
}
