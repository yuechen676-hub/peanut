// Emoji clock with real-time and accelerated simulation modes.
// Controls:
//   T -> toggle real-time / simulation
//   LEFT/RIGHT -> switch displayed segment (manual override visual; time still advances)
//   1-6 -> jump to a segment display (visual only)
//   + / - -> increase / decrease simulation speed (only affects simulation mode)

let activities = [
  { name: "Daytime games",   emoji: "🕹️☀️", minutes: 330, type: "fun"    },
  { name: "Night game",      emoji: "🎮🌛", minutes: 180, type: "fun"    },
  { name: "Social time",     emoji: "📱📺", minutes: 350, type: "fun"    },
  { name: "Commuting time",  emoji: "💻🚌", minutes: 75,  type: "work"   },
  { name: "Mealtime",        emoji: "🍜🍱", minutes: 80,  type: "neutral"},
  { name: "Bath and Sleep",  emoji: "🛁😴", minutes: 425, type: "sleep"  },
];

const MINUTES_PER_EMOJI = 15;   // one emoji represents this many minutes
let totalMinutes = 0;           // will be computed from activities
let cumu = [];                  // cumulative minute boundaries

// timing & mode
let useRealTime = false;        // false -> simulation, true -> system clock
let simSpeed = 60;              // only used when useRealTime==false (minutes per second)
                                // default 60 => 1 real second = 60 virtual minutes (fast demo)

let manualDisplayIndex = -1;    // -1 => automatic (follows time); >=0 => show that segment for debugging/view
let idx = 0;                    // currently selected index for keyboard jumps (keeps UI consistent)

function setup() {
  createCanvas(900, 600);
  textAlign(CENTER, CENTER);
  noStroke();

  // compute totals and cumulative boundaries
  totalMinutes = 0;
  cumu = [0];
  for (let a of activities) {
    totalMinutes += a.minutes;
    cumu.push(totalMinutes);
  }
}

function draw() {
  background(245);

  // ---- 1) compute virtual minute of day (vmin) ----
  let vmin;
  if (useRealTime) {
    // real clock mode
    let d = new Date();
    vmin = d.getHours() * 60 + d.getMinutes() + d.getSeconds() / 60.0;
    // keep in [0, totalMinutes)
    vmin = vmin % totalMinutes;
  } else {
    // simulation mode: advance using millis()
    let elapsedSec = millis() / 1000.0;
    let elapsedMin = elapsedSec * simSpeed;
    vmin = elapsedMin % totalMinutes;
  }

  // ---- 2) find active segment index and progress within it ----
  let activeIndex = findActiveIndex(vmin); // index determined by time
  let segmentStart = cumu[activeIndex];
  let segmentEnd = cumu[activeIndex + 1];
  let progress = constrain((vmin - segmentStart) / (segmentEnd - segmentStart), 0, 1); // 0..1

  // if manualDisplayIndex is set, show that segment instead for visualization
  let displayIndex = (manualDisplayIndex >= 0) ? manualDisplayIndex : activeIndex;
  let displayAct = activities[displayIndex];

  // ---- 3) compute counts ----
  // full number of emojis representing the whole segment
  let fullCount = max(1, floor(displayAct.minutes / MINUTES_PER_EMOJI));

  // if we are showing the *active* segment, fill according to progress
  // otherwise we show either full (past) or 0 (future). For simplicity we show full for all non-active segments.
  let filledCount;
  if (displayIndex === activeIndex) {
    filledCount = floor(fullCount * progress); // how many emojis are "completed" in this segment
    // ensure at least 1 visible so screen isn't empty when progress small
    filledCount = max(1, filledCount);
  } else {
    // show full representation for other segments (you can change to 0 if you prefer)
    filledCount = fullCount;
  }

  // ---- 4) layout grid and draw filledCount emojis ----
  // grid computed from filledCount
  let cols = max(1, ceil(sqrt(filledCount)));
  let rows = max(1, ceil(filledCount / cols));

  let marginTop = 90;
  let margin = 40;
  let cellW = (width - margin * 2) / cols;
  let cellH = (height - marginTop - margin) / rows;
  let cellSize = min(cellW, cellH);

  let gridW = cols * cellSize;
  let gridH = rows * cellSize;
  let startX = (width - gridW) / 2 + cellSize / 2;
  let startY = marginTop + (height - marginTop - gridH) / 2 + cellSize / 2;

  // header: show mode and which segment is active by time
  fill(30);
  textSize(18);
  let modeLabel = useRealTime ? "Real Time" : `Sim (speed=${simSpeed} min/sec)`;
  text(`${modeLabel} — Active by time: ${activities[activeIndex].name}`, width / 2, 28);
  fill(100);
  textSize(12);
  text("T: toggle real/sim   ←→: switch display segment   1-6: jump", width / 2, 46);

  // Draw emojis (filled portion)
  drawingContext.globalAlpha = 1.0;
  textSize(cellSize * 0.72);
  let p = 0;
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (p >= filledCount) break;
      let x = startX + c * cellSize;
      let y = startY + r * cellSize;
      text(displayAct.emoji, x, y);
      p++;
    }
  }

  // small footer with segment info
  fill(80);
  textSize(14);
  text(`${displayAct.name} — ${displayAct.minutes} min  (showing ${filledCount}/${fullCount})`, width / 2, height - 20);
}

// find which segment index contains vmin
function findActiveIndex(vmin) {
  for (let i = 0; i < cumu.length - 1; i++) {
    if (vmin >= cumu[i] && vmin < cumu[i + 1]) return i;
  }
  return cumu.length - 2;
}

/* --- keyboard handlers --- */
function keyPressed() {
  if (key === 'T' || key === 't') {
    useRealTime = !useRealTime;
  } else if (keyCode === LEFT_ARROW) {
    // switch manual display to previous (toggle between manual and automatic by manualDisplayIndex)
    if (manualDisplayIndex < 0) manualDisplayIndex = 0;
    manualDisplayIndex = (manualDisplayIndex - 1 + activities.length) % activities.length;
  } else if (keyCode === RIGHT_ARROW) {
    if (manualDisplayIndex < 0) manualDisplayIndex = 0;
    manualDisplayIndex = (manualDisplayIndex + 1) % activities.length;
  } else if (key >= '1' && key <= '6') {
    manualDisplayIndex = int(key) - 1;
  } else if (key === '+' || key === '=') {
    // increase simulation speed (only meaningful in sim mode)
    simSpeed = min(simSpeed + 15, 1440); // cap to 1 day per sec
  } else if (key === '-' || key === '_') {
    simSpeed = max(1, simSpeed - 15);
  } else if (key === 'A' || key === 'a') {
    // press 'A' to return to automatic display following time
    manualDisplayIndex = -1;
  }
}
